//Rodrigo Garcia Mayo
//A01024595
//Assignment 3 - Simple image manipulation

#include "PPM.h"

void mem_free (struct PPM* ppm) //Frees allocated memory
{
    free(ppm->rgb[0]);
    free(ppm->rgb);
}

void mem_alloc (struct PPM *ppm) //Memory allocation for ppm
{
    ppm->rgb = (RGB**)malloc(ppm->height * sizeof(RGB *));
    ppm->rgb[0] = (RGB*)calloc((ppm->width) * (ppm->height), sizeof(RGB));
    for(int i = 1; i < (ppm->height); i++)
    {
        ppm->rgb[i] = ppm->rgb[0] + ppm->width * i;
    }
}

void ASCII_read (struct PPM* ppm, FILE *file) //Read P3 files
{
    for (int r=0;r<ppm->height;r++)
    {
        for (int c=0;c<ppm->width;c++)
        {
            fscanf(file,"%hhu", &ppm->rgb[r][c].rgb[0]);
            fscanf(file,"%hhu", &ppm->rgb[r][c].rgb[1]);
            fscanf(file,"%hhu", &ppm->rgb[r][c].rgb[2]);
        }
    }
}

void Binary_read(struct PPM* ppm, FILE *file) //Read P6 files
{
    fread (ppm->rgb[0], sizeof(RGB), ppm->width * ppm->height, file);
}

struct PPM img_read(char *file_name) //Read a ppm
{
    struct PPM ppm;
    FILE *file = fopen(file_name, "r");
    if (!file) {
        printf("Unable to open file '%s'\n", file_name);
        exit(-1);
    }
    fgets(ppm.magic_number, sizeof(ppm.magic_number), file);

    fscanf (file, "%d %d", &ppm.width, &ppm.height);
    fscanf (file, "%d", &ppm.max_color);

    fgetc(file);

    /*printf("%s\n", ppm.magic_number);
    printf("%d\n", ppm.width);
    printf("%d\n", ppm.height);
    printf("%d\n", ppm.max_color);*/

    mem_alloc(&ppm);
    if (ppm.magic_number[0] == 'P' && ppm.magic_number[1] == '3')
        ASCII_read(&ppm, file);
    if (ppm.magic_number[0] == 'P' && ppm.magic_number[1] == '6')
        Binary_read(&ppm, file);

    fclose(file);

    return ppm;
}

void write_Binary_PPM(const char *filename, PPM image) //Writes to a file a P6 ppm
{
    printf("Writing new image as: %s...\n", filename);
    FILE *file;
    file = fopen(filename, "wb");

    fprintf(file, "%c%c\n", image.magic_number[0], image.magic_number[1]);

    fprintf(file, "%d %d\n",image.width,image.height);

    fprintf(file, "%d\n", image.max_color);

    fwrite (image.rgb[0], sizeof(RGB), image.width * image.height, file);

    fclose(file);
}

void write_ASCII_PPM(const char *filename, PPM image) //Writes to a file a P3 ppm
{
    printf("Writing new image as: %s...\n", filename);

    FILE *file;
    file = fopen(filename, "wb");

    fprintf(file, "%c%c\n", image.magic_number[0], image.magic_number[1]);

    fprintf(file, "%d %d\n",image.width,image.height);

    fprintf(file, "%d\n", image.max_color);

    for (int r=0;r<image.height;r++)
    {
        for (int c=0;c<image.width;c++)
        {
            fprintf(file,"%3hhu\t", image.rgb[r][c].rgb[0]);
            fprintf(file,"%3hhu\t", image.rgb[r][c].rgb[1]);
            fprintf(file,"%3hhu\t", image.rgb[r][c].rgb[2]);
        }
        fprintf(file,"\n");
    }
    fclose(file);
}

void write_img(const char *filename, PPM image) //Write a ppm image to file
{
    if (image.magic_number[0] == 'P' && image.magic_number[1] == '3')
        write_ASCII_PPM(filename, image);
    if (image.magic_number[0] == 'P' && image.magic_number[1] == '6')
        write_Binary_PPM(filename, image);
}

void negative_img (struct PPM* ppm) //Negative pixels for the ppm
{
    for (int r=0;r<ppm->height;r++)
    {
        for (int c = 0; c < ppm->width; c++)
        {
            ppm->rgb[r][c].rgb[0] = ppm->max_color - ppm->rgb[r][c].rgb[0];
            ppm->rgb[r][c].rgb[1] = ppm->max_color - ppm->rgb[r][c].rgb[1];
            ppm->rgb[r][c].rgb[2] = ppm->max_color - ppm->rgb[r][c].rgb[2];
        }
    }
}

void resize_img (struct PPM* original, int scale) //Resizing the image to scale
{
    struct PPM res_ppm;
    strncpy(res_ppm.magic_number, original->magic_number, 3);
    float reduction = 100.0 / scale;

    res_ppm.width = original->width / reduction;
    res_ppm.height = original->height/reduction;

    mem_alloc(&res_ppm);


    if (reduction > 1) //Making image smaller
    {
        for (int r=0;r<res_ppm.height;r++)
        {
            for (int c=0;c<res_ppm.width;c++)
            {
                res_ppm.rgb[r]->rgb[c*3] = pixel_avg(original, r * 2, c * 3 * 2);
                res_ppm.rgb[r]->rgb[(c*3)+1] = pixel_avg(original, r * 2, (c + 1) * 3 * 2);
                res_ppm.rgb[r]->rgb[(c*3)+2] = pixel_avg(original, r*2, (c+2)*3*2);
            }
        }
    }
    if (reduction < 1) //Making image bigger
    {
        for (int r=0;r<original->height;r++)
        {
            for (int c = 0; c < original->width; c++)
            {
                    res_ppm.rgb[r*2]->rgb[c*3*2] = original->rgb[r]->rgb[(c*3)];
                    res_ppm.rgb[r*2]->rgb[(c*3*2)+1] = original->rgb[r]->rgb[(c*3)+1];
                    res_ppm.rgb[r*2]->rgb[(c*3*2)+2] = original->rgb[r]->rgb[(c*3)*2];
            }
        }
        /*for (int r=1;r<res_ppm.height-1;r++)
        {
            for (int c = 3; c < res_ppm.width-3; c=c+2)
            {
                res_ppm.rgb[r]->rgb[c*3] = res_ppm.rgb[r-1]->rgb[(c*3)];
                res_ppm.rgb[r]->rgb[(c*3)+1] = res_ppm.rgb[r-1]->rgb[(c*3)+1];
                res_ppm.rgb[r]->rgb[(c*3)+2] = res_ppm.rgb[r-1]->rgb[(c*3)*2];
            }
        }*/
    }
    //free(original);
    *original = res_ppm;
    //mem_free(&res_ppm);

}

int pixel_avg (struct PPM* original, int bound_r, int bound_c) //Gets the average of RGB pixels from a certain area of the image
{
    int avg = 0;
    int cont_avg = 0;
    for (int r=bound_r;r<=bound_r/*+1*/;r++)
    {
        for (int c=bound_c;c<=bound_c+3;c=c+3)
        {
            avg += original->rgb[r]->rgb[c];
            cont_avg++;
        }
    }
    avg /= cont_avg;
    //printf("Avg: %d\n", avg);
    //printf("Cont: %d\n", cont_avg);

    return avg;
}