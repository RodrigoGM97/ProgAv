//Rodrigo Garcia Mayo
//A01024595
//Assignment 3 - Simple image manipulation

#include "PPM.h"

void menu (char* input, char* output, int negative, int scale);//Does input options

void menu (char* input, char* output, int negative, int scale)//Does input options
{
    struct PPM image;
    image = img_read(input);
    //printf("%3hhu\n", image.rgb[2]->rgb[5]);
    //image.rgb[2]->rgb[5] = 125;
    if (scale != 100)
        resize_img(&image, scale);
    if (negative == 1)
        negative_img(&image);
    write_img(output, image);
    mem_free(&image);
}

int main(int argc, char **argv)
{
    char *input_file = NULL;
    char *output_file = NULL;
    int scale = 100;
    int negative = 0;
    int option=0;

    while ((option = getopt(argc, argv, "i:o:s:n")) != -1 ) //Read input
    {
        switch (option)
        {
            case 'i':
                input_file = optarg;
                break;
            case 'o':
                output_file = optarg;
                break;
            case 'n':
                negative = 1;
                break;
            case 's':
                scale = atoi(optarg);
                break;
            default:
                printf("Invalid option '%c'\n", option);
                break;
        }
    }
    menu(input_file, output_file, negative, scale); //Does input options

    return 0;
}