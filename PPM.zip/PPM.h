//Rodrigo Garcia Mayo
//A01024595
//Assignment 3 - Simple image manipulation

#ifndef PPM_H
#define PPM_H

#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <string.h>

typedef struct RGB
{
    unsigned char rgb[3];
}RGB;

typedef struct PPM
{
    char magic_number[3];
    int width;
    int height;
    int max_color;
    RGB** rgb;
} PPM;

struct PPM img_read(char *file_name); //Read a ppm

void Binary_read (struct PPM* ppm, FILE *file); //Read P6 files

void ASCII_read(struct PPM*, FILE *file); //Read P3 files

void write_img(const char *filename, PPM image); //Write a ppm image to file

void write_Binary_PPM(const char *filename, PPM image); //Writes to a file a P6 ppm

void write_ASCII_PPM(const char *filename, PPM image); //Writes to a file a P3 ppm

void negative_img (struct PPM* ppm); //Negative pixels for the ppm

void mem_free (struct PPM* ppm); //Frees allocated memory

void mem_alloc (struct PPM *ppm); //Memory allocation for ppm

void resize_img (struct PPM* original, int scale); //Resizing the image to scale

int pixel_avg (struct PPM* original, int bound_r, int bound_c); //Gets the average of RGB pixels from a certain area of the image


#endif
